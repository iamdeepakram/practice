import logo from './logo.svg';
import './App.css';
import Header from './components/header/Header';
import PromoImage from './components/promoimage/PromoImage';
import EmailSubscription from './components/email/EmailSubscription';

function App() {
  return (
    <div className="App">
      <Header/>
      <PromoImage/>
      <EmailSubscription/>
    </div>
  );
}

export default App;
