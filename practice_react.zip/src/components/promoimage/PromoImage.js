import React from 'react';
import girImg from './img/girlImg.png'
import './promoImage.css'

const PromoImage = () => {
  return (
      <div className="image">
        <img src={girImg} ></img>
      </div>

  );
};

export default PromoImage;
