import React from 'react';
import girImg from './img/girlImg.png'
import './promoImage.css'

const PromoImage = () => {
  return (
      <div className="image">
      
      </div>

  );
};

export default PromoImage;
